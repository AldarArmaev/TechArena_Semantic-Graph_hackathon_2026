-- DB ts_assurance
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_assurance
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_assurance`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_assurance` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_assurance`;

--
-- Table structure for table `assurance`
--

DROP TABLE IF EXISTS `assurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assurance` (
  `assurance_id` varchar(255) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `assurance_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`assurance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assurance`
--

LOCK TABLES `assurance` WRITE;
/*!40000 ALTER TABLE `assurance` DISABLE KEYS */;
INSERT INTO `assurance` VALUES ('307bbd01-0729-4619-b246-b314ae5b4565','ff17fee9-fcf8-4f51-8a59-3af9794971e1','TRAFFIC_ACCIDENT'),('4eee5ace-bbc9-4680-b778-9db4d8bc72b3','26cce1d3-279a-4e66-9e34-bce30d2f5adb','TRAFFIC_ACCIDENT');
/*!40000 ALTER TABLE `assurance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_auth
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_auth
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_auth`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_auth` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_auth`;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `user_id` varchar(36) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_name` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES ('06cfd7e8-6b58-4b8b-b548-80a60e891f3f','$2a$10$SkEfMVkmmZo8kBxOReCCA.9aN4QPkyafigWxTTHA/ffktK6gyEcVG','admin'),('1c8e9ffd-45bd-4c80-b43b-974d991ae1be','$2a$10$sQjNlREt3xzlUVvJuzChO.eYYTe.WExGoTDHrBe1rfvwA2GNM4KKG','MRK-reg-430'),('4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','$2a$10$C9f5SMoFW7Wzbrg4ig1roeXyfCLzk36jJaVAN5iV4JkMCcegn9SNq','fdse_microservice'),('714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','$2a$10$fy2o.L3ffcWrB3FG4LDTUOyIiXG7ySJqoIecB4eVz6JdPDkQwsgJm','MRK-payer-133');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` varchar(36) NOT NULL,
  `roles` varchar(255) DEFAULT NULL,
  KEY `FKmdtdu7txekccv58vkr6emnl1m` (`user_id`),
  CONSTRAINT `FKmdtdu7txekccv58vkr6emnl1m` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES ('4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','ROLE_USER'),('06cfd7e8-6b58-4b8b-b548-80a60e891f3f','ROLE_ADMIN'),('714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','ROLE_USER'),('1c8e9ffd-45bd-4c80-b43b-974d991ae1be','ROLE_USER');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_config
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_config
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_config`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_config` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_config`;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('DirectTicketAllocationProportion','Allocation Proportion Of The Direct Ticket - From Start To End','0.5');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_consign
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_consign
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_consign`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_consign` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_consign`;

--
-- Table structure for table `consign_record`
--

DROP TABLE IF EXISTS `consign_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consign_record` (
  `consign_record_id` varchar(255) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `consignee` varchar(255) DEFAULT NULL,
  `from_place` varchar(255) DEFAULT NULL,
  `handle_date` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `consign_record_phone` varchar(255) DEFAULT NULL,
  `consign_record_price` double DEFAULT NULL,
  `target_date` varchar(255) DEFAULT NULL,
  `to_place` varchar(255) DEFAULT NULL,
  `weight` double NOT NULL,
  PRIMARY KEY (`consign_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consign_record`
--

LOCK TABLES `consign_record` WRITE;
/*!40000 ALTER TABLE `consign_record` DISABLE KEYS */;
INSERT INTO `consign_record` VALUES ('0b9358e6-3446-4f52-b0ae-8e140593bbad','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-cons2-656','shanghai','2026-10-01','866576ae-93f7-4025-a02d-cb20cc436bb3','13100000000',20,'2026-10-01','suzhou',4),('14d4851f-2659-4322-9d97-57cd0d72b4c2','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','7a9caf38-d38c-4df1-bc3f-cabba04fde6c','13100000000',12,'2026-10-01','suzhou',2),('21240e79-ac5c-4219-8946-4c903b71ff84','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-cons-581','shanghai','2026-10-01','ff17fee9-fcf8-4f51-8a59-3af9794971e1','13200000000',16,'2026-10-01','suzhou',3),('23a85718-abeb-4d6c-8041-da5e780e8870','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','MRK-consignee-763','shanghai','2026-10-01','5df0bd4f-59fe-4d19-9136-5ecd60a0c3ef','13100000000',12,'2026-10-01','nanjing',2),('31a1afc3-44af-4479-ae6b-9568f2fd2af4','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','26cce1d3-279a-4e66-9e34-bce30d2f5adb','13100000000',12,'2026-10-01','nanjing',2),('454e17c8-3124-4440-b2a5-9bd016b67180','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','1afc5f4a-4108-4511-9260-922436aebd1a','13100000000',12,'2026-10-01','nanjing',2),('7c64dea1-c6cf-4e95-8bf9-0762790facb3','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','MRK-consignee-763','shanghai','2026-10-01','6a2fc059-6009-41bb-969f-53dd1db7f937','13100000000',12,'2026-10-01','suzhou',2),('83461c9b-1b65-4529-9d61-be9c4be73b46','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','922549b8-c1ac-4511-a992-90f2471a3aac','13100000000',12,'2026-10-01','nanjing',2),('8f1c7369-cf07-4732-9d18-de9c567bc525','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','afab5b6f-2aa4-4fea-9110-97776aa78eb0','13100000000',12,'2026-10-01','nanjing',2),('c69eefa8-c012-4670-9123-4577ece2d0db','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','26288089-ead9-4f1b-bece-2e7efce33969','13100000000',12,'2026-10-01','nanjing',2),('d7fc0292-d16a-4b49-93df-6446698a2be5','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','44395f64-9da7-4743-8cda-8f1e647d53fa','13100000000',12,'2026-10-01','nanjing',2),('f49775cd-9332-4552-ab29-7910e3208270','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','972ab213-e324-4499-ae39-68cc2b736f0a','13100000000',12,'2026-10-01','suzhou',2),('f8a7c2cc-558f-402b-9490-b3923a259d7b','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-consignee-763','shanghai','2026-10-01','ff17fee9-fcf8-4f51-8a59-3af9794971e1','13100000000',12,'2026-10-01','suzhou',2);
/*!40000 ALTER TABLE `consign_record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_consign_price
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_consign_price
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_consign_price`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_consign_price` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_consign_price`;

--
-- Table structure for table `consign_price`
--

DROP TABLE IF EXISTS `consign_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consign_price` (
  `id` varchar(36) NOT NULL,
  `beyond_price` double DEFAULT NULL,
  `idx` int DEFAULT NULL,
  `initial_price` double DEFAULT NULL,
  `initial_weight` double DEFAULT NULL,
  `within_price` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_lgier9psog5spnqru5luet1sv` (`idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consign_price`
--

LOCK TABLES `consign_price` WRITE;
/*!40000 ALTER TABLE `consign_price` DISABLE KEYS */;
INSERT INTO `consign_price` VALUES ('7367e574-f038-435f-9336-c63076819562',4,0,8,1,2);
/*!40000 ALTER TABLE `consign_price` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_contacts
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_contacts
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_contacts`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_contacts` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_contacts`;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `document_number` varchar(255) DEFAULT NULL,
  `document_type` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_document_idx` (`account_id`,`document_number`,`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES ('0fbada85-5e91-4b6a-924b-6e60795f7cd3','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','MRK-pc',1,'MRK-pcontact-399','1'),('13c4af04-4405-4a44-9053-1001a78a9e21','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','DocumentNumber_Two',1,'Contacts_Two','ContactsPhoneNum_Two'),('225c7f52-fd28-47dd-8432-6004edd2a065','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-adoc',1,'MRK-acontact-725','1'),('ade501e2-50e9-4696-bdef-fb031a798126','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','DocumentNumber_One',1,'Contacts_One','ContactsPhoneNum_One'),('fb4dca5e-f507-4d9e-a5c5-1f5f6202e291','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','MRK-doc3',1,'MRK-adm-168','13000000002');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_delivery
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_delivery
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_delivery`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_delivery` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_delivery`;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
  `id` varchar(36) NOT NULL,
  `food_name` varchar(255) DEFAULT NULL,
  `order_id` binary(255) DEFAULT NULL,
  `station_name` varchar(255) DEFAULT NULL,
  `store_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES ('2c686fb3-9545-4c64-a991-189e12e37fe3','HotPot',_binary '\��)\�\�Le��iN_\�!W\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Shang Hai','MiaoTing Instant-Boiled Mutton'),('5334bfec-6c6f-46b6-a79a-6c26d1769412','Spicy hot noodles',_binary '�%I���E���\�G\Z:�\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,NULL),('7b022e45-512a-476c-bf52-ca2732c53433','Big Burger',_binary '�*�\�$D��9h\�+so\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','suzhou','Roman Holiday'),('bdd6b1ac-dd9d-40e1-87db-388dae2f458f','Spicy hot noodles',_binary '��\���OQ�Y:�yIq\�\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,NULL);
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_food
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_food
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_food`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_food` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_food`;

--
-- Table structure for table `food_order`
--

DROP TABLE IF EXISTS `food_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_order` (
  `id` varchar(36) NOT NULL,
  `food_name` varchar(255) DEFAULT NULL,
  `food_type` int NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `station_name` varchar(255) DEFAULT NULL,
  `store_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_order`
--

LOCK TABLES `food_order` WRITE;
/*!40000 ALTER TABLE `food_order` DISABLE KEYS */;
INSERT INTO `food_order` VALUES ('0f00569b-edbc-4226-b482-9c943b5ed1cf','Big Burger',2,'972ab213-e324-4499-ae39-68cc2b736f0a',1.2,'suzhou','Roman Holiday'),('3d1c9905-4395-42b4-a180-7d4d2a76e41b','Spicy hot noodles',1,'922549b8-c1ac-4511-a992-90f2471a3aac',5,NULL,NULL),('6aa82913-17fc-41f9-9837-2037c4dc92eb','Spicy hot noodles',1,'ff17fee9-fcf8-4f51-8a59-3af9794971e1',5,NULL,NULL);
/*!40000 ALTER TABLE `food_order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_food_delivery
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_food_delivery
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_food_delivery`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_food_delivery` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_food_delivery`;

--
-- Table structure for table `food_delivery_order`
--

DROP TABLE IF EXISTS `food_delivery_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_delivery_order` (
  `id` varchar(36) NOT NULL,
  `created_time` varchar(255) DEFAULT NULL,
  `delivery_fee` double NOT NULL,
  `delivery_time` varchar(255) DEFAULT NULL,
  `seat_no` int NOT NULL,
  `station_food_store_id` varchar(255) DEFAULT NULL,
  `trip_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_delivery_order`
--

LOCK TABLES `food_delivery_order` WRITE;
/*!40000 ALTER TABLE `food_delivery_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `food_delivery_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_delivery_order_food_list`
--

DROP TABLE IF EXISTS `food_delivery_order_food_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_delivery_order_food_list` (
  `food_delivery_order_id` varchar(36) NOT NULL,
  `food_name` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  KEY `FK7qff03pst9g4hm7fieqeqf8ta` (`food_delivery_order_id`),
  CONSTRAINT `FK7qff03pst9g4hm7fieqeqf8ta` FOREIGN KEY (`food_delivery_order_id`) REFERENCES `food_delivery_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_delivery_order_food_list`
--

LOCK TABLES `food_delivery_order_food_list` WRITE;
/*!40000 ALTER TABLE `food_delivery_order_food_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `food_delivery_order_food_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_inside_payment
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_inside_payment
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_inside_payment`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_inside_payment` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_inside_payment`;

--
-- Table structure for table `inside_money`
--

DROP TABLE IF EXISTS `inside_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inside_money` (
  `id` varchar(36) NOT NULL,
  `money` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inside_money`
--

LOCK TABLES `inside_money` WRITE;
/*!40000 ALTER TABLE `inside_money` DISABLE KEYS */;
INSERT INTO `inside_money` VALUES ('05f1c9c2-ce78-48ce-8663-9400c5fa3b2f','40.00','D','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('56ae57dd-e446-4e70-aac2-014f2d6a7be8','1','D','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('645b23f1-28e4-4874-a29b-d25a23221b33','10000','A','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('9671ee2b-7f89-4d44-94c3-b250fce5db1d','40.00','D','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('bbf4ac0f-f8fa-4269-88c7-21bc58f96119','280.00','D','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('c723a110-d62c-4b00-aa7f-5bafd0629d43','50.0','A','drawback'),('fe08cfee-80f2-426b-9c95-fb672b92390d','230.0','A','drawback');
/*!40000 ALTER TABLE `inside_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inside_payment`
--

DROP TABLE IF EXISTS `inside_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inside_payment` (
  `id` varchar(36) NOT NULL,
  `order_id` varchar(36) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inside_payment`
--

LOCK TABLES `inside_payment` WRITE;
/*!40000 ALTER TABLE `inside_payment` DISABLE KEYS */;
INSERT INTO `inside_payment` VALUES ('0b4a818f-c2c7-450d-b85a-df704a81bc20','ff17fee9-fcf8-4f51-8a59-3af9794971e1','50.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('2db2b2c7-606a-44fc-b90d-e65af441ef66','7a9caf38-d38c-4df1-bc3f-cabba04fde6c','50.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('3961e378-4978-4523-af33-5b4af6689047','922549b8-c1ac-4511-a992-90f2471a3aac','350.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('3a316ef0-6f33-4291-887c-966d5a5af6f7','44395f64-9da7-4743-8cda-8f1e647d53fa','350.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('82c06977-01ee-4bc3-bd63-6985dcf498b8','26288089-ead9-4f1b-bece-2e7efce33969','350.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('a1ab043d-8923-4def-8778-52d1d70fe218','972ab213-e324-4499-ae39-68cc2b736f0a','50.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('acb9a2a5-4a9f-4851-9d0f-f8fa9c30876c','7a9caf38-d38c-4df1-bc3f-cabba04fde6c','0','E',''),('be94d607-0437-4b6a-bf13-74831c902e3b','6a2fc059-6009-41bb-969f-53dd1db7f937','50.0','O','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d'),('c1a873e6-124d-46d5-a86e-5bb5d9607bc4','1afc5f4a-4108-4511-9260-922436aebd1a','120.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f'),('efbe2f0e-8d78-4db7-b0b0-d2c5074736fb','1afc5f4a-4108-4511-9260-922436aebd1a','230.0','E',''),('f2fbeeac-8bf9-40fa-97a0-016f76c2fff5','5df0bd4f-59fe-4d19-9136-5ecd60a0c3ef','350.0','O','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d'),('f9b71d96-f835-4a56-b83a-814d714ec86a','26cce1d3-279a-4e66-9e34-bce30d2f5adb','350.0','P','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f');
/*!40000 ALTER TABLE `inside_payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_notification
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_notification
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_notification`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_notification` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_notification`;

--
-- Table structure for table `notify_info`
--

DROP TABLE IF EXISTS `notify_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notify_info` (
  `id` varchar(36) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `end_place` varchar(255) DEFAULT NULL,
  `order_number` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `seat_class` varchar(255) DEFAULT NULL,
  `seat_number` varchar(255) DEFAULT NULL,
  `send_status` bit(1) DEFAULT NULL,
  `start_place` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notify_info`
--

LOCK TABLES `notify_info` WRITE;
/*!40000 ALTER TABLE `notify_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `notify_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_order
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_order
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_order`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_order` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_order`;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `bought_date` varchar(255) DEFAULT NULL,
  `coach_number` int NOT NULL,
  `contacts_document_number` varchar(255) DEFAULT NULL,
  `contacts_name` varchar(255) DEFAULT NULL,
  `document_type` int NOT NULL,
  `from_station` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `seat_class` int NOT NULL,
  `seat_number` varchar(255) DEFAULT NULL,
  `status` int NOT NULL,
  `to_station` varchar(255) DEFAULT NULL,
  `train_number` varchar(255) DEFAULT NULL,
  `travel_date` varchar(255) DEFAULT NULL,
  `travel_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('1afc5f4a-4108-4511-9260-922436aebd1a','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:17',5,'DocumentNumber_One','Contacts_One',1,'shanghai','120.0',2,'498593155',1,'nanjing','G9998','2026-10-01','2026-10-01 09:00:00'),('2f106aca-a0ae-426c-8d8b-89d9899bd7a0','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 14:58:11',5,'DocumentNumber_One','Contacts_One',1,'shanghai','100.0',2,'FirstClass-30',0,'beijing','G1234','2022-10-01 00:00:00','2022-10-01 00:00:00'),('5ed1aefd-ee85-4a4b-9a89-ecc984e2b3b7','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-10-01',1,'1','MRK-aorder',1,'shanghai','1',2,'1',0,'suzhou','D1345','2026-10-01','2026-10-01'),('6a2fc059-6009-41bb-969f-53dd1db7f937','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','2026-09-15 15:00:14',5,'MRK-pc','MRK-pcontact-399',1,'shanghai','50.0',2,'1786716268',1,'suzhou','D1345','2026-10-01','2013-05-04 07:00:00'),('7a9caf38-d38c-4df1-bc3f-cabba04fde6c','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:10',5,'DocumentNumber_One','Contacts_One',1,'shanghai','0',3,'301180960',3,'suzhou','D1345','2026-10-01','2013-05-04 07:00:00'),('866576ae-93f7-4025-a02d-cb20cc436bb3','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:11',5,'DocumentNumber_One','Contacts_One',1,'shanghai','50.0',2,'1968299627',4,'suzhou','D1345','2026-10-01','2013-05-04 07:00:00'),('972ab213-e324-4499-ae39-68cc2b736f0a','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:12',5,'DocumentNumber_One','Contacts_One',1,'shanghai','50.0',2,'881368389',4,'suzhou','D1345','2026-10-01','2013-05-04 07:00:00'),('c7337453-bc38-4ae1-bfa5-a7216e2bf501','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 14:58:11',5,'DocumentNumber_One','Contacts_One',1,'shanghai','100.0',2,'FirstClass-30',0,'beijing','G1235','2022-10-01 00:00:00','2022-10-01 00:00:00'),('e6f4e300-7d8d-4631-b3fb-c625a9bbf4ad','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 14:58:11',5,'DocumentNumber_One','Contacts_One',1,'nanjing','100.0',2,'FirstClass-30',0,'shanghaihongqiao','G1237','2022-10-01 00:00:00','2022-10-01 00:00:00'),('ff17fee9-fcf8-4f51-8a59-3af9794971e1','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:04',5,'DocumentNumber_One','Contacts_One',1,'shanghai','50.0',2,'140721045',6,'suzhou','D1345','2026-10-01','2013-05-04 07:00:00');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_order_other
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_order_other
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_order_other`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_order_other` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_order_other`;

--
-- Table structure for table `orders_other`
--

DROP TABLE IF EXISTS `orders_other`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_other` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `bought_date` varchar(255) DEFAULT NULL,
  `coach_number` int NOT NULL,
  `contacts_document_number` varchar(255) DEFAULT NULL,
  `contacts_name` varchar(255) DEFAULT NULL,
  `document_type` int NOT NULL,
  `from_station` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `seat_class` int NOT NULL,
  `seat_number` varchar(255) DEFAULT NULL,
  `status` int NOT NULL,
  `to_station` varchar(255) DEFAULT NULL,
  `train_number` varchar(255) DEFAULT NULL,
  `travel_date` varchar(255) DEFAULT NULL,
  `travel_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_other`
--

LOCK TABLES `orders_other` WRITE;
/*!40000 ALTER TABLE `orders_other` DISABLE KEYS */;
INSERT INTO `orders_other` VALUES ('26288089-ead9-4f1b-bece-2e7efce33969','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:11',5,'DocumentNumber_One','Contacts_One',1,'shanghai','350.0',2,'109714051',3,'nanjing','Z1234','2026-10-01','2013-05-04 09:51:52'),('26cce1d3-279a-4e66-9e34-bce30d2f5adb','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:06',5,'DocumentNumber_One','Contacts_One',1,'shanghai','350.0',2,'1389063211',6,'nanjing','Z1234','2026-10-01','2013-05-04 09:51:52'),('44395f64-9da7-4743-8cda-8f1e647d53fa','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:18',5,'DocumentNumber_One','Contacts_One',1,'shanghai','350.0',2,'1478107884',1,'nanjing','Z1234','2026-10-01','2013-05-04 09:51:52'),('5df0bd4f-59fe-4d19-9136-5ecd60a0c3ef','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','2026-09-15 15:00:15',5,'MRK-pc','MRK-pcontact-399',1,'shanghai','350.0',2,'1389958114',1,'nanjing','Z1234','2026-10-01','2013-05-04 09:51:52'),('922549b8-c1ac-4511-a992-90f2471a3aac','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:13',5,'DocumentNumber_One','Contacts_One',1,'shanghai','350.0',2,'808408597',1,'nanjing','Z1234','2026-10-01','2013-05-04 09:51:52'),('9edfa9ca-8993-49ff-9f52-013085598ea0','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-10-01',1,'1','MRK-aorder2',1,'shanghai','1',2,'1',0,'nanjing','K1345','2026-10-01','2026-10-01'),('afab5b6f-2aa4-4fea-9110-97776aa78eb0','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 15:00:12',5,'DocumentNumber_One','Contacts_One',1,'shanghai','350.0',2,'1176593015',4,'nanjing','Z1234','2026-10-01','2013-05-04 09:51:52'),('ef78f4b2-2afc-4918-a54b-8b65c9ef452c','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2026-09-15 14:58:11',5,'Test','Test',1,'shanghai','100',2,'6A',1,'taiyuan','K1235','2022-10-01 00:00:00','2022-10-01 00:00:00');
/*!40000 ALTER TABLE `orders_other` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_payment
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_payment
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_payment`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_payment` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_payment`;

--
-- Table structure for table `money`
--

DROP TABLE IF EXISTS `money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `money` (
  `id` varchar(36) NOT NULL,
  `money` varchar(255) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `money`
--

LOCK TABLES `money` WRITE;
/*!40000 ALTER TABLE `money` DISABLE KEYS */;
/*!40000 ALTER TABLE `money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `id` varchar(36) NOT NULL,
  `order_id` varchar(36) DEFAULT NULL,
  `payment_price` varchar(255) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES ('19e7399e-39d4-4729-95b6-fa077c260d08','6a2fc059-6009-41bb-969f-53dd1db7f937','50.0','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d'),('329f66ef-0f26-4b81-99ec-49c29755af82','5df0bd4f-59fe-4d19-9136-5ecd60a0c3ef','350.0','714afb0b-6d20-4d5f-9032-7b63cd3f1e5d'),('36f9e7a6-e017-4b3b-b2a4-c02e2c3611f7','5ad7750b-a68b-49c0-a8c0-32776b067701','10000.0','4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_price
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_price
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_price`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_price` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_price`;

--
-- Table structure for table `price_config`
--

DROP TABLE IF EXISTS `price_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_config` (
  `id` varchar(36) NOT NULL,
  `basic_price_rate` double NOT NULL,
  `first_class_price_rate` double NOT NULL,
  `route_id` varchar(36) DEFAULT NULL,
  `train_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `route_type_idx` (`train_type`,`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_config`
--

LOCK TABLES `price_config` WRITE;
/*!40000 ALTER TABLE `price_config` DISABLE KEYS */;
INSERT INTO `price_config` VALUES ('0eb474c9-f8be-4119-8681-eb538a404a6a',0.2,1,'1367db1f-461e-4ab7-87ad-2bcc05fd9cb7','KuaiSu'),('6d20b8cb-039c-474c-ae25-b6177ea41152',0.38,1,'92708982-77af-4318-be25-57ccb0ff69ad','GaoTieOne'),('719287d6-d3e7-4b54-9a92-71d039748b22',0.7,1,'a3f256c1-0e43-4f7d-9c21-121bf258101f','GaoTieOne'),('7de18cf8-bb17-4bb2-aeb4-85d8176d3a93',0.6,1,'084837bb-53c8-4438-87c8-0321a4d09917','GaoTieTwo'),('8b059dc5-01a2-4f8f-8f94-6c886b38bb34',0.32,1,'d693a2c5-ef87-4a3c-bef8-600b43f62c68','ZhiDa'),('8fb01829-393f-4af4-9e96-f72866f94d14',0.35,1,'9fc9c261-3263-4bfa-82f8-bb44e06b2f52','ZhiDa'),('b90a6ad7-ffad-4624-9655-48e9e185fa6c',0.35,1,'0b23bd3e-876a-4af3-b920-c50a90c90b04','ZhiDa'),('c5679b7e-4a54-4f52-9939-1ae86ba16fa7',0.5,1,'aefcef3f-3f42-46e8-afd7-6cb2a928bd3d','GaoTieOne'),('d5c4523a-827c-468c-95be-e9024a40572e',0.45,1,'f3d4d4ef-693b-4456-8eed-59c0d717dd08','DongCheOne'),('dd0e572e-7443-420c-8280-7d8215636069',0.3,1,'20eb7122-3a11-423f-b10a-be0dc5bce7db','TeKuai');
/*!40000 ALTER TABLE `price_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_route
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_route
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_route`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_route` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_route`;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `id` varchar(36) NOT NULL,
  `end_station` varchar(255) DEFAULT NULL,
  `start_station` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES ('084837bb-53c8-4438-87c8-0321a4d09917','shanghai','suzhou'),('0b23bd3e-876a-4af3-b920-c50a90c90b04','taiyuan','shanghai'),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7','hangzhou','shanghaihongqiao'),('20eb7122-3a11-423f-b10a-be0dc5bce7db','taiyuan','shanghai'),('92708982-77af-4318-be25-57ccb0ff69ad','shanghai','nanjing'),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52','beijing','nanjing'),('a3f256c1-0e43-4f7d-9c21-121bf258101f','shanghai','nanjing'),('aefcef3f-3f42-46e8-afd7-6cb2a928bd3d','shanghai','nanjing'),('d693a2c5-ef87-4a3c-bef8-600b43f62c68','shanghai','taiyuan'),('f3d4d4ef-693b-4456-8eed-59c0d717dd08','suzhou','shanghai');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_distances`
--

DROP TABLE IF EXISTS `route_distances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_distances` (
  `route_id` varchar(36) NOT NULL,
  `distances` int DEFAULT NULL,
  `distances_order` int NOT NULL,
  PRIMARY KEY (`route_id`,`distances_order`),
  CONSTRAINT `FKckw3orheb0uxsmn4tsbqm2sjm` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_distances`
--

LOCK TABLES `route_distances` WRITE;
/*!40000 ALTER TABLE `route_distances` DISABLE KEYS */;
INSERT INTO `route_distances` VALUES ('084837bb-53c8-4438-87c8-0321a4d09917',0,0),('084837bb-53c8-4438-87c8-0321a4d09917',50,1),('0b23bd3e-876a-4af3-b920-c50a90c90b04',0,0),('0b23bd3e-876a-4af3-b920-c50a90c90b04',350,1),('0b23bd3e-876a-4af3-b920-c50a90c90b04',1000,2),('0b23bd3e-876a-4af3-b920-c50a90c90b04',1300,3),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7',0,0),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7',150,1),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7',300,2),('20eb7122-3a11-423f-b10a-be0dc5bce7db',0,0),('20eb7122-3a11-423f-b10a-be0dc5bce7db',1300,1),('92708982-77af-4318-be25-57ccb0ff69ad',0,0),('92708982-77af-4318-be25-57ccb0ff69ad',100,1),('92708982-77af-4318-be25-57ccb0ff69ad',150,2),('92708982-77af-4318-be25-57ccb0ff69ad',200,3),('92708982-77af-4318-be25-57ccb0ff69ad',250,4),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52',0,0),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52',500,1),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52',700,2),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52',1200,3),('a3f256c1-0e43-4f7d-9c21-121bf258101f',0,0),('a3f256c1-0e43-4f7d-9c21-121bf258101f',200,1),('a3f256c1-0e43-4f7d-9c21-121bf258101f',250,2),('aefcef3f-3f42-46e8-afd7-6cb2a928bd3d',0,0),('aefcef3f-3f42-46e8-afd7-6cb2a928bd3d',250,1),('d693a2c5-ef87-4a3c-bef8-600b43f62c68',0,0),('d693a2c5-ef87-4a3c-bef8-600b43f62c68',300,1),('d693a2c5-ef87-4a3c-bef8-600b43f62c68',950,2),('d693a2c5-ef87-4a3c-bef8-600b43f62c68',1300,3),('f3d4d4ef-693b-4456-8eed-59c0d717dd08',0,0),('f3d4d4ef-693b-4456-8eed-59c0d717dd08',50,1);
/*!40000 ALTER TABLE `route_distances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_stations`
--

DROP TABLE IF EXISTS `route_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_stations` (
  `route_id` varchar(36) NOT NULL,
  `stations` varchar(255) DEFAULT NULL,
  `stations_order` int NOT NULL,
  PRIMARY KEY (`route_id`,`stations_order`),
  CONSTRAINT `FKhqsqnv54tl5xpepgh8q524rlu` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_stations`
--

LOCK TABLES `route_stations` WRITE;
/*!40000 ALTER TABLE `route_stations` DISABLE KEYS */;
INSERT INTO `route_stations` VALUES ('084837bb-53c8-4438-87c8-0321a4d09917','suzhou',0),('084837bb-53c8-4438-87c8-0321a4d09917','shanghai',1),('0b23bd3e-876a-4af3-b920-c50a90c90b04','shanghai',0),('0b23bd3e-876a-4af3-b920-c50a90c90b04','nanjing',1),('0b23bd3e-876a-4af3-b920-c50a90c90b04','shijiazhuang',2),('0b23bd3e-876a-4af3-b920-c50a90c90b04','taiyuan',3),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7','shanghaihongqiao',0),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7','jiaxingnan',1),('1367db1f-461e-4ab7-87ad-2bcc05fd9cb7','hangzhou',2),('20eb7122-3a11-423f-b10a-be0dc5bce7db','shanghai',0),('20eb7122-3a11-423f-b10a-be0dc5bce7db','taiyuan',1),('92708982-77af-4318-be25-57ccb0ff69ad','nanjing',0),('92708982-77af-4318-be25-57ccb0ff69ad','zhenjiang',1),('92708982-77af-4318-be25-57ccb0ff69ad','wuxi',2),('92708982-77af-4318-be25-57ccb0ff69ad','suzhou',3),('92708982-77af-4318-be25-57ccb0ff69ad','shanghai',4),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52','nanjing',0),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52','xuzhou',1),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52','jinan',2),('9fc9c261-3263-4bfa-82f8-bb44e06b2f52','beijing',3),('a3f256c1-0e43-4f7d-9c21-121bf258101f','nanjing',0),('a3f256c1-0e43-4f7d-9c21-121bf258101f','suzhou',1),('a3f256c1-0e43-4f7d-9c21-121bf258101f','shanghai',2),('aefcef3f-3f42-46e8-afd7-6cb2a928bd3d','nanjing',0),('aefcef3f-3f42-46e8-afd7-6cb2a928bd3d','shanghai',1),('d693a2c5-ef87-4a3c-bef8-600b43f62c68','taiyuan',0),('d693a2c5-ef87-4a3c-bef8-600b43f62c68','shijiazhuang',1),('d693a2c5-ef87-4a3c-bef8-600b43f62c68','nanjing',2),('d693a2c5-ef87-4a3c-bef8-600b43f62c68','shanghai',3),('f3d4d4ef-693b-4456-8eed-59c0d717dd08','shanghai',0),('f3d4d4ef-693b-4456-8eed-59c0d717dd08','suzhou',1);
/*!40000 ALTER TABLE `route_stations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_security
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_security
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_security`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_security` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_security`;

--
-- Table structure for table `security_config`
--

DROP TABLE IF EXISTS `security_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_config` (
  `id` varchar(36) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_config`
--

LOCK TABLES `security_config` WRITE;
/*!40000 ALTER TABLE `security_config` DISABLE KEYS */;
INSERT INTO `security_config` VALUES ('50d47f04-3b35-40ca-a561-4d7ec0cd5c06','Max in 1 hour','max_order_1_hour','2147483647'),('97597835-c234-4ad5-99ac-3f1e2ff9e0fb','Max not used','max_order_not_use','2147483647');
/*!40000 ALTER TABLE `security_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_station
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_station
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_station`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_station` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_station`;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `stay_time` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_gnneuc0peq2qi08yftdjhy7ok` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES ('393da3cc-7a84-4843-90c8-db797383a474','shanghaihongqiao',10),('3c06f768-bfae-4d98-a662-996a1a29eec2','zhenjiang',2),('43e9cc13-ca25-4192-a355-d916859f1cdd','shijiazhuang',8),('545f1b3f-6a50-432f-a39c-36c0eff8771a','jiaxingnan',2),('6c505ab5-9ab5-4735-b4cf-c71b153e0807','suzhou',3),('71e03c23-63ea-4794-b756-fa9af4fa7896','jinan',5),('8630f393-e019-4f64-891b-d424fe0a9c5a','xuzhou',7),('a6612d23-5474-4032-9d8a-7f49be7b0bf2','taiyuan',5),('af6986ff-aa96-4f9c-8c0c-f91800aac5cc','shanghai',10),('b3ebf5a9-c913-43ec-810f-0d30901daa20','hangzhou',9),('c8c00aea-2f38-46d2-885d-e698fe385eb8','beijing',10),('e3097f1a-b415-43f7-9c2e-463ac6eb9281','nanjing',8),('fa0e6c92-f7b2-4147-b43a-e9bcd2f24303','wuxi',3);
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_station_food
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_station_food
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_station_food`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_station_food` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_station_food`;

--
-- Table structure for table `station_food_list`
--

DROP TABLE IF EXISTS `station_food_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station_food_list` (
  `store_id` varchar(255) NOT NULL,
  `food_name` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  KEY `FK789k11aygpihdosaug6hrh7r2` (`store_id`),
  CONSTRAINT `FK789k11aygpihdosaug6hrh7r2` FOREIGN KEY (`store_id`) REFERENCES `station_food_store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station_food_list`
--

LOCK TABLES `station_food_list` WRITE;
/*!40000 ALTER TABLE `station_food_list` DISABLE KEYS */;
INSERT INTO `station_food_list` VALUES ('935a6d1f-f726-435c-9411-ae42a3629681','Hamburger',5),('935a6d1f-f726-435c-9411-ae42a3629681','Cola',2),('935a6d1f-f726-435c-9411-ae42a3629681','Chicken',10.5),('11575967-38cb-44e7-8bd1-fe780605f42c','Rice',1.2),('11575967-38cb-44e7-8bd1-fe780605f42c','Chicken Soup',2.5),('9fdfc336-b15d-40ed-baf4-31cf2db44eec','Big Burger',1.2),('9fdfc336-b15d-40ed-baf4-31cf2db44eec','Bone Soup',2.5),('f521201e-e7e3-4cbe-9c31-fb3c39d353e1','Big Burger',1.2),('f521201e-e7e3-4cbe-9c31-fb3c39d353e1','Bone Soup',2.5),('c06241e7-4829-4278-b2fd-368298f96bf6','Big Mac',2.2),('c06241e7-4829-4278-b2fd-368298f96bf6','McChicken',1.5),('4bbabfe2-6796-458d-a82e-fa5bc576431e','Big Burger',1.2),('4bbabfe2-6796-458d-a82e-fa5bc576431e','Bone Soup',2.5),('eb8583bf-d54a-4191-a5a1-deeb6a86ac19','French Fries',1.2),('eb8583bf-d54a-4191-a5a1-deeb6a86ac19','Vegetable Seafood Soup',2.5),('fb16da12-3964-40e1-8a0a-89ae58329a89','Hot Chocolate',1.2),('fb16da12-3964-40e1-8a0a-89ae58329a89','Pineapple Pie',2.5),('6ca997a4-2f26-4fd7-8870-49e9b1db27bc','Karubi Beef',1.2),('6ca997a4-2f26-4fd7-8870-49e9b1db27bc',' Low Fat Yogurt Blackberry',2.5);
/*!40000 ALTER TABLE `station_food_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `station_food_store`
--

DROP TABLE IF EXISTS `station_food_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station_food_store` (
  `store_id` varchar(255) NOT NULL,
  `business_time` varchar(255) DEFAULT NULL,
  `delivery_fee` double NOT NULL,
  `station_name` varchar(255) DEFAULT NULL,
  `store_name` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`store_id`),
  UNIQUE KEY `station_store_idx` (`station_name`,`store_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station_food_store`
--

LOCK TABLES `station_food_store` WRITE;
/*!40000 ALTER TABLE `station_food_store` DISABLE KEYS */;
INSERT INTO `station_food_store` VALUES ('11575967-38cb-44e7-8bd1-fe780605f42c','08:00-21:00',10,'shanghai','Good Taste','6228480012'),('4bbabfe2-6796-458d-a82e-fa5bc576431e','09:00-23:00',15,'suzhou','Roman Holiday','3769464'),('6ca997a4-2f26-4fd7-8870-49e9b1db27bc','08:00-21:00',15,'taiyuan','GOODWILL','23753855'),('935a6d1f-f726-435c-9411-ae42a3629681','10:00-20:00',20,'shanghai','KFC','01-234567'),('9fdfc336-b15d-40ed-baf4-31cf2db44eec','08:00-23:00',15,'nanjing','Burger King','88348215681'),('c06241e7-4829-4278-b2fd-368298f96bf6','08:00-23:00',15,'nanjing','McDonald\'s','2836485'),('eb8583bf-d54a-4191-a5a1-deeb6a86ac19','08:00-23:00',15,'beijing','Perfect','975335664'),('f521201e-e7e3-4cbe-9c31-fb3c39d353e1','08:00-23:00',15,'nanjing','Pizza Hut','2382614'),('fb16da12-3964-40e1-8a0a-89ae58329a89','08:00-21:00',15,'beijing','Delicious','237452946');
/*!40000 ALTER TABLE `station_food_store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_train
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_train
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_train`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_train` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_train`;

--
-- Table structure for table `train_type`
--

DROP TABLE IF EXISTS `train_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `train_type` (
  `id` varchar(36) NOT NULL,
  `average_speed` int DEFAULT NULL,
  `confort_class` int DEFAULT NULL,
  `economy_class` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_3ayk8fx1ak7c37s5udyh8n3s2` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_type`
--

LOCK TABLES `train_type` WRITE;
/*!40000 ALTER TABLE `train_type` DISABLE KEYS */;
INSERT INTO `train_type` VALUES ('2adef67a-de38-46c4-895d-c0b4dc97f44a',100,10,10,'MRK-train'),('37d29e6e-91aa-48b9-adb7-e940a0b61f47',200,2147483647,2147483647,'GaoTieTwo'),('6043cac9-9b03-44b7-9aa5-aafdc1db4ab1',120,2147483647,2147483647,'ZhiDa'),('8094fb9d-9792-479d-b78a-270cf84f64c3',120,2147483647,2147483647,'TeKuai'),('abb9f418-f89d-4da9-bbdb-d21bb7f13d55',250,2147483647,2147483647,'GaoTieOne'),('ac3bfd20-345c-40f2-a604-ced8e73e43cc',90,2147483647,2147483647,'KuaiSu'),('d21e2815-8482-4d8d-a754-a60f080d4592',180,2147483647,2147483647,'DongCheOne');
/*!40000 ALTER TABLE `train_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_train_food
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_train_food
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_train_food`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_train_food` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_train_food`;

--
-- Table structure for table `train_food`
--

DROP TABLE IF EXISTS `train_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `train_food` (
  `id` varchar(36) NOT NULL,
  `trip_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_104u6slgvuqsgue17v5p4cx45` (`trip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_food`
--

LOCK TABLES `train_food` WRITE;
/*!40000 ALTER TABLE `train_food` DISABLE KEYS */;
INSERT INTO `train_food` VALUES ('13611416-5c31-4fe1-9ec7-c89cfb08cd00','D1345'),('0e49e5fe-fd4b-4a4e-bd07-4fcf32bc2ecd','G1234'),('626f2198-988d-4caf-a16b-ab5df6d4f67f','G1235'),('e06ab133-8d96-44cd-a826-34ac8d408720','G1236'),('528fbc17-dec7-444f-a827-d076a04058b3','G1237');
/*!40000 ALTER TABLE `train_food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `train_food_list`
--

DROP TABLE IF EXISTS `train_food_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `train_food_list` (
  `trip_id` varchar(36) NOT NULL,
  `food_name` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  KEY `FKjf1mr4qeh5wxc3rxhoe8oxwm1` (`trip_id`),
  CONSTRAINT `FKjf1mr4qeh5wxc3rxhoe8oxwm1` FOREIGN KEY (`trip_id`) REFERENCES `train_food` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_food_list`
--

LOCK TABLES `train_food_list` WRITE;
/*!40000 ALTER TABLE `train_food_list` DISABLE KEYS */;
INSERT INTO `train_food_list` VALUES ('0e49e5fe-fd4b-4a4e-bd07-4fcf32bc2ecd','Pork Chop with rice',9.5),('0e49e5fe-fd4b-4a4e-bd07-4fcf32bc2ecd','Egg Soup',3.2),('626f2198-988d-4caf-a16b-ab5df6d4f67f','Beef with rice',9.5),('626f2198-988d-4caf-a16b-ab5df6d4f67f','Soup',3.7),('626f2198-988d-4caf-a16b-ab5df6d4f67f','Pork pickled mustard green noodles',10),('e06ab133-8d96-44cd-a826-34ac8d408720','Seafood noodles',9.5),('e06ab133-8d96-44cd-a826-34ac8d408720','Glutinous rice',0.9),('e06ab133-8d96-44cd-a826-34ac8d408720','Dumplings',5.5),('528fbc17-dec7-444f-a827-d076a04058b3','Spring rolls',1.5),('528fbc17-dec7-444f-a827-d076a04058b3','Vegetable soup',0.8),('528fbc17-dec7-444f-a827-d076a04058b3','Rice and vegetable roll',1),('13611416-5c31-4fe1-9ec7-c89cfb08cd00','Spicy hot noodles',5),('13611416-5c31-4fe1-9ec7-c89cfb08cd00','Soup',3.7),('13611416-5c31-4fe1-9ec7-c89cfb08cd00','Oily bean curd',2);
/*!40000 ALTER TABLE `train_food_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_travel
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_travel
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_travel`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_travel` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_travel`;

--
-- Table structure for table `trip`
--

DROP TABLE IF EXISTS `trip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trip` (
  `id` varchar(36) NOT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `route_id` varchar(255) DEFAULT NULL,
  `start_station_name` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `stations_name` varchar(255) DEFAULT NULL,
  `terminal_station_name` varchar(255) DEFAULT NULL,
  `train_type_name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `type` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trip`
--

LOCK TABLES `trip` WRITE;
/*!40000 ALTER TABLE `trip` DISABLE KEYS */;
INSERT INTO `trip` VALUES ('222ec138-1caf-4db7-b521-fb3641376f33','2013-05-04 17:51:52','aefcef3f-3f42-46e8-afd7-6cb2a928bd3d','shanghai','2013-05-04 12:00:00','suzhou','taiyuan','GaoTieOne','1235',0),('32c19e89-d195-4a98-9c59-3fe571e71e07','2013-05-04 20:51:52','a3f256c1-0e43-4f7d-9c21-121bf258101f','shanghai','2013-05-04 14:00:00','suzhou','taiyuan','GaoTieOne','1236',0),('70c8ac4b-93a4-4929-b7a0-23542dc3888b','2013-05-04 15:51:52','92708982-77af-4318-be25-57ccb0ff69ad','shanghai','2013-05-04 09:00:00','suzhou','taiyuan','GaoTieOne','1234',0),('8bc2a00d-5afd-4e86-94b3-2bbb6e3bcf1d','2013-05-04 19:59:52','f3d4d4ef-693b-4456-8eed-59c0d717dd08','shanghai','2013-05-04 07:00:00','suzhou','taiyuan','DongCheOne','1345',1),('b3697201-247e-4b3a-9178-b6fb9b1c0f57','2026-10-01 13:00:00','0b23bd3e-876a-4af3-b920-c50a90c90b04','shanghai','2026-10-01 09:00:00','nanjing','taiyuan','GaoTieOne','9998',0),('c723482d-50cf-418c-ab5f-a260bc1167bf','2013-05-04 17:21:52','084837bb-53c8-4438-87c8-0321a4d09917','shanghai','2013-05-04 08:00:00','suzhou','taiyuan','GaoTieTwo','1237',0);
/*!40000 ALTER TABLE `trip` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_travel2
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_travel2
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_travel2`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_travel2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_travel2`;

--
-- Table structure for table `trip2`
--

DROP TABLE IF EXISTS `trip2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trip2` (
  `id` varchar(36) NOT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `route_id` varchar(255) DEFAULT NULL,
  `start_station_name` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `stations_name` varchar(255) DEFAULT NULL,
  `terminal_station_name` varchar(255) DEFAULT NULL,
  `train_type_name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `type` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trip2`
--

LOCK TABLES `trip2` WRITE;
/*!40000 ALTER TABLE `trip2` DISABLE KEYS */;
INSERT INTO `trip2` VALUES ('2156280e-dc04-4d0a-8a73-d97e97b9d71d','2013-05-04 17:51:52','9fc9c261-3263-4bfa-82f8-bb44e06b2f52','shanghai','2013-05-04 11:31:52','nanjing','beijing','ZhiDa','1235',2),('21a661f2-43c6-4652-ac28-a220b68e8ae8','2013-05-04 19:59:52','1367db1f-461e-4ab7-87ad-2bcc05fd9cb7','shanghai','2013-05-04 07:51:52','nanjing','beijing','KuaiSu','1345',4),('914c24db-82c5-407b-b6c9-e180f0bd847a','2013-05-04 17:21:52','20eb7122-3a11-423f-b10a-be0dc5bce7db','shanghai','2013-05-04 08:31:52','nanjing','beijing','TeKuai','1235',3),('bfbe9a0d-9420-404e-9eb6-04aa3f96084d','2013-05-04 12:51:52','d693a2c5-ef87-4a3c-bef8-600b43f62c68','shanghai','2013-05-04 7:05:52','nanjing','beijing','ZhiDa','1236',2),('f02a1605-1d7f-40a9-ae8a-80d5a4dac24b','2013-05-04 15:51:52','0b23bd3e-876a-4af3-b920-c50a90c90b04','shanghai','2013-05-04 09:51:52','nanjing','beijing','ZhiDa','1234',2);
/*!40000 ALTER TABLE `trip2` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_user
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_user
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_user`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_user` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_user`;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` varchar(36) NOT NULL,
  `document_num` varchar(255) DEFAULT NULL,
  `document_type` int DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` int NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('1c8e9ffd-45bd-4c80-b43b-974d991ae1be','MRK-rdoc',1,'reg@example.com',1,'111111','MRK-reg-430'),('4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f','2135488099312X',1,'trainticket_notify@163.com',1,'111111','fdse_microservice'),('714afb0b-6d20-4d5f-9032-7b63cd3f1e5d','MRK-pdoc',1,'p@example.com',1,'111111','MRK-payer-133');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
-- DB ts_wait_order
-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: ts_wait_order
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ts_wait_order`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ts_wait_order` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ts_wait_order`;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15  8:00:37
